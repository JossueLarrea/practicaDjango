from django.apps import AppConfig


class GestionClientesConfig(AppConfig):
    name = 'gestion_clientes'

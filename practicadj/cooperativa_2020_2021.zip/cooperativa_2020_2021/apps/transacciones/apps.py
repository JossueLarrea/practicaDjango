from django.apps import AppConfig


class TransaccionesConfig(AppConfig):
    name = 'transacciones'
